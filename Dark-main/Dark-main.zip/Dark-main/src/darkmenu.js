const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎 𝘿𝙊 𝙎𝙊𝙇𝙍𝘼𝘾:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  𝙏𝙍𝘼𝘿𝙐𝙕𝙄𝘿𝙊 𝙋𝙊𝙍 *𝙎𝙊𝙇𝙍𝘼𝘾*
  DUVIDAS? 👇
  WA.me/5588981321692
╚════════════════════`
}

exports.darkmenu = darkmenu








